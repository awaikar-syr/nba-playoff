This repository should contain all files for your group project. You should only use one repository (owned by the point of contact) for the group.

Submissions for each checkpoint will be placed in the relevant folders. You are welcome to create other folders, but I will only look for a file called "submission.md" in the respective checkpoint folder when it comes time to grade assignments.